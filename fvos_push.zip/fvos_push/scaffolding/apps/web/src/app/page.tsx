export default function HomePage() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-8">
      <div className="text-center">
        <h1 className="text-4xl font-bold tracking-tight text-white">
          Faceless Viral OS
        </h1>
        <p className="mt-4 text-lg text-gray-400">
          Automated faceless video content platform
        </p>
        <div className="mt-8 flex gap-4 justify-center">
          <a href="/dashboard" className="btn-primary">
            Go to Dashboard
          </a>
          <a href="/api/health" className="btn-secondary" target="_blank" rel="noreferrer">
            API Health
          </a>
        </div>
      </div>
    </main>
  );
}
